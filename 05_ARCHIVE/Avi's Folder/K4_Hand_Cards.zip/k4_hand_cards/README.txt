Hand derivation examples for K4 verification
